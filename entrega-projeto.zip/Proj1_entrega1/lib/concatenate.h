#ifndef CONCATENATE_H

char* strConcatenate(char* str1, char* str2);

#endif